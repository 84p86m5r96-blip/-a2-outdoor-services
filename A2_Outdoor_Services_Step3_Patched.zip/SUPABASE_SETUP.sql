-- A2 Outdoor Services: calendar + guest booking setup
-- Run this in Supabase SQL Editor before publishing the new index.html.

-- Allow guest bookings.
alter table public.bookings
alter column user_id drop not null;

-- Owner-controlled unavailable dates.
create table if not exists public.blocked_dates (
  date date primary key,
  reason text
);

alter table public.blocked_dates enable row level security;

drop policy if exists "Anyone can view blocked dates" on public.blocked_dates;
create policy "Anyone can view blocked dates"
on public.blocked_dates
for select
to anon, authenticated
using (true);

drop policy if exists "Owners can add blocked dates" on public.blocked_dates;
create policy "Owners can add blocked dates"
on public.blocked_dates
for insert
to authenticated
with check (public.is_owner());

drop policy if exists "Owners can update blocked dates" on public.blocked_dates;
create policy "Owners can update blocked dates"
on public.blocked_dates
for update
to authenticated
using (public.is_owner())
with check (public.is_owner());

drop policy if exists "Owners can delete blocked dates" on public.blocked_dates;
create policy "Owners can delete blocked dates"
on public.blocked_dates
for delete
to authenticated
using (public.is_owner());

-- Make sure guests can insert bookings.
drop policy if exists "Anyone can create bookings" on public.bookings;
create policy "Anyone can create bookings"
on public.bookings
for insert
to anon, authenticated
with check (
  user_id is null
  or user_id = auth.uid()
);

-- IMPORTANT:
-- The HTML checks availability for display, but a production site should enforce
-- the 10-per-day limit atomically on the database too. Add that RPC before launch
-- if multiple customers may book at the same time.

-- Secure booking creation: blocks unavailable dates and enforces max 10 active bookings per day.
create or replace function public.create_booking(
  p_user_id uuid,
  p_name text,
  p_phone text,
  p_address text,
  p_service text,
  p_price numeric,
  p_appointment_date date,
  p_appointment_time text,
  p_payment_method text
)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare
  new_booking public.bookings;
  daily_count integer;
begin
  if exists (
    select 1 from public.blocked_dates
    where date = p_appointment_date
  ) then
    raise exception 'This date is unavailable.';
  end if;

  select count(*)
  into daily_count
  from public.bookings
  where appointment_date = p_appointment_date
    and coalesce(booking_status, '') <> 'cancelled';

  if daily_count >= 10 then
    raise exception 'This date is fully booked.';
  end if;

  insert into public.bookings (
    user_id, name, phone, address, service, price,
    appointment_date, appointment_time, payment_method,
    payment_status, booking_status
  )
  values (
    p_user_id, p_name, p_phone, p_address, p_service, p_price,
    p_appointment_date, p_appointment_time, p_payment_method,
    'pending', 'pending'
  )
  returning * into new_booking;

  return new_booking;
end;
$$;

grant execute on function public.create_booking(
  uuid,text,text,text,text,numeric,date,text,text
) to anon, authenticated;
